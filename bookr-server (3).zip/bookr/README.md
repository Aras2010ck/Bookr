# BOOKR mit Auto-Suche (Google Gemini)

Der Server sucht selbst im Web (Gemini mit Google-Suche), prüft jeden Link und schickt dir passende Gigs mit fertiger Bewerbungsnachricht.

## Schlüssel holen
aistudio.google.com → "Get API key". Den Schlüssel NIE in eine Datei oder in den Chat schreiben, nur bei Render eintragen.

## Online stellen (Render, ca. 10 Minuten)
1. github.com: neues Repository "bookr", diese Dateien hochladen: server.js, index.html, package.json
2. render.com: New → Web Service → dein Repository wählen
3. Start Command: `node server.js`
4. Environment Variables:
   - GEMINI_API_KEY = dein Google-Schlüssel
   - ACCESS_CODE = ein eigener Code (schützt dich vor Fremden)
   - optional DAILY_LIMIT = Suchen pro Tag (Standard 15)
   - optional MODEL = anderes Gemini-Modell (Standard gemini-2.5-flash)
5. Link am Handy öffnen, "Zum Home-Bildschirm" oder "App installieren"

## Benutzen
Daten eintragen oder leer lassen, 🤖 Gigs suchen tippen. Beim ersten Mal fragt die App nach dem Zugangscode.
