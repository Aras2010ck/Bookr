const http=require("http"),fs=require("fs"),path=require("path");
const KEY=process.env.GEMINI_API_KEY||"AIzaSyBmpLTSI8kKalX7uvCv1UFoZyKD05N8uYo",CODE=process.env.ACCESS_CODE||"",PORT=process.env.PORT||3000;
const MODEL=process.env.MODEL||"gemini-2.5-flash",LIMIT=+process.env.DAILY_LIMIT||15;
let day="",used=0;const jobs={};
const send=(res,c,o)=>{res.writeHead(c,{"content-type":"application/json"});res.end(JSON.stringify(o))};
const body=req=>new Promise(r=>{let b="";req.on("data",c=>{b+=c;if(b.length>2e5)req.destroy()});req.on("end",()=>r(b))});
const ANGLES=["Anzeigen, Gesuche und Ausschreibungen (Google, Kleinanzeigen, Foren, Facebook-Gruppen, Jobbörsen)","Clubs, Bars, Veranstalter, Agenturen und Booking-Plattformen, die DJs suchen oder Slots vergeben, sowie Aufrufe auf Instagram, TikTok und Reddit"];
async function alive(u){try{const r=await fetch(u,{redirect:"follow",signal:AbortSignal.timeout(7000),headers:{"user-agent":"Mozilla/5.0"}});return r.status<400||[401,403,429].includes(r.status)}catch(e){return false}}
async function search(q,p,angle){
  const today=new Date().toISOString().slice(0,10);
  const prompt=`Heute ist ${today}. Du bist der Gig-Scout eines DJs und suchst im Web nach echten, aktuellen Gig-Möglichkeiten.
DJ-Profil: Name ${p.name||"-"}, Stadt ${p.city}, Genres ${p.genres||"offen"}, Gigtypen ${(p.types||[]).join(", ")}, Mindestgage ${p.fee||0} €, Bio: ${p.bio||"-"}, Instagram: ${p.ig||"-"}, Mix: ${p.mix||"-"}.
Suchwunsch: ${q||"alles, was zum Profil passt"}
Schwerpunkt dieser Suche: ${angle}. Suche in und nahe ${p.city}. Nutze mehrere verschiedene Suchanfragen.
Regeln: Nur Treffer mit echter URL aus den Suchergebnissen. Nichts erfinden. Bevorzuge aktuelle Treffer. DJs, die sich selbst anbieten, sind keine Gigs.
Antworte NUR mit einem JSON-Array (max. 8 Einträge). Felder je Eintrag: title, ort, fee (Zahl in Euro oder ""), fit (0-100, wie gut es zum Profil passt), why (ein Satz, warum es passt oder was fehlt), note (Datum, Genre, Alter der Anzeige), contact (Name, Mail, Nummer oder @Handle, falls bekannt), apply (wie man sich bewirbt, z. B. "Mail", "Instagram-DM", "Formular auf der Seite"), url, source (z. B. Google, Forum), pitch (fertige, freundliche deutsche Bewerbungsnachricht in Ich-Form von ${p.name||"dem DJ"}, bezieht sich auf diesen Treffer, nennt Genres, Bio, Mix-Link und Instagram, höchstens 70 Wörter). Leeres Array, wenn nichts Passendes gefunden wurde.`;
  const r=await fetch("https://generativelanguage.googleapis.com/v1beta/models/"+MODEL+":generateContent",{method:"POST",
    headers:{"x-goog-api-key":KEY,"content-type":"application/json"},
    body:JSON.stringify({contents:[{role:"user",parts:[{text:prompt}]}],tools:[{google_search:{}}],generationConfig:{temperature:0.3,maxOutputTokens:8000}})});
  const j=await r.json();
  if(!r.ok)throw new Error((j.error&&j.error.message)||("API "+r.status));
  const parts=(((j.candidates||[])[0]||{}).content||{}).parts||[];
  const t=parts.map(x=>x.text||"").join("\n");
  const m=t.match(/\[[\s\S]*\]/);
  let arr=[];try{arr=m?JSON.parse(m[0]):[]}catch(e){}
  const ok=await Promise.all(arr.map(x=>x&&/^https?:\/\//.test(x.url||"")?alive(x.url):false));
  return arr.filter((x,i)=>ok[i]);
}
function startJob(q,p){
  const id=Math.random().toString(36).slice(2),J=jobs[id]={status:"läuft",gigs:[],done:0,total:ANGLES.length};
  ANGLES.forEach(a=>search(q,p,a).then(g=>{g.forEach(x=>{if(x&&x.url&&!J.gigs.some(y=>y.url===x.url))J.gigs.push(x)})})
    .catch(e=>{J.err=String(e.message||e)}).finally(()=>{if(++J.done===J.total)J.status="fertig"}));
  setTimeout(()=>delete jobs[id],36e5);return id;
}
http.createServer(async(req,res)=>{
  try{
    const ok=()=>!CODE||req.headers["x-code"]===CODE;
    if(req.method==="GET"&&req.url==="/api/ping")return send(res,200,{ok:true});
    if(req.method==="GET"&&req.url.startsWith("/api/job/")){const J=jobs[req.url.slice(9)];return J?send(res,200,J):send(res,404,{error:"Suche nicht gefunden"})}
    if(req.method==="POST"&&req.url==="/api/search"){
      if(!KEY)return send(res,500,{error:"GEMINI_API_KEY fehlt auf dem Server"});
      if(!ok())return send(res,401,{error:"Zugangscode falsch"});
      const d=new Date().toISOString().slice(0,10);if(d!==day){day=d;used=0}
      if(used>=LIMIT)return send(res,429,{error:"Tageslimit erreicht ("+LIMIT+" Suchen)"});
      used++;const {q,profile}=JSON.parse(await body(req)||"{}");
      return send(res,200,{id:startJob(String(q||"").slice(0,200),profile||{city:"München"})});
    }
    if(req.method==="GET"){res.writeHead(200,{"content-type":"text/html; charset=utf-8"});return res.end(fs.readFileSync(path.join(__dirname,"index.html")))}
    res.writeHead(404);res.end();
  }catch(e){send(res,500,{error:String(e.message||e)})}
}).listen(PORT,()=>console.log("BOOKR läuft auf Port "+PORT));
